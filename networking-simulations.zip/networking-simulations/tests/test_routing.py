"""
test_routing.py — Unit tests for network routing.
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from src.topology.network import Network
from src.topology.node import Node, NodeType
from src.topology.link import Link
from src.topology.topologies import create_star_network, create_mesh_network, create_ring_network


class TestShortestPath:

    def setup_method(self):
        self.net = Network("TestNet")
        for nid in ["A", "B", "C", "D"]:
            self.net.add_node(Node(nid))
        self.net.add_link(Link("A", "B", latency=1))
        self.net.add_link(Link("B", "C", latency=1))
        self.net.add_link(Link("A", "D", latency=10))
        self.net.add_link(Link("D", "C", latency=10))

    def test_direct_path(self):
        path = self.net.shortest_path("A", "B")
        assert path == ["A", "B"]

    def test_multi_hop_path(self):
        path = self.net.shortest_path("A", "C")
        assert path == ["A", "B", "C"]  # cost 2 < cost 20

    def test_no_path(self):
        isolated = Node("Z")
        self.net.add_node(isolated)
        assert self.net.shortest_path("A", "Z") is None

    def test_node_failure_reroutes(self):
        self.net.nodes["B"].fail()
        path = self.net.shortest_path("A", "C")
        # Should now go A -> D -> C
        assert "B" not in path

    def test_node_recovery(self):
        self.net.nodes["B"].fail()
        self.net.nodes["B"].recover()
        path = self.net.shortest_path("A", "C")
        assert path == ["A", "B", "C"]


class TestTopologies:

    def test_star_node_count(self):
        net = create_star_network(nodes=5)
        assert len(net.nodes) == 6  # 1 hub + 5 hosts

    def test_mesh_fully_connected(self):
        net = create_mesh_network(nodes=4)
        for src in net.nodes:
            for dst in net.nodes:
                if src != dst:
                    path = net.shortest_path(src, dst)
                    assert path is not None, f"No path {src}->{dst}"

    def test_ring_connectivity(self):
        net = create_ring_network(nodes=6)
        path = net.shortest_path("Node-0", "Node-3")
        assert path is not None


class TestPacketRouting:

    def test_packet_delivered(self):
        from src.utils.packet import Packet, Protocol
        net = create_star_network(nodes=3)
        nodes = list(net.nodes.values())
        src = nodes[1]
        dst = nodes[2]
        pkt = Packet(src_ip=src.ip, dst_ip=dst.ip, protocol=Protocol.ICMP)
        result = net.route_packet(pkt)
        assert result["success"] is True

    def test_packet_dropped_on_link_down(self):
        from src.utils.packet import Packet, Protocol
        net = create_star_network(nodes=2)
        for link in net.links.values():
            link.loss_rate = 1.0  # 100% loss
        nodes = list(net.nodes.values())
        pkt = Packet(src_ip=nodes[1].ip, dst_ip=nodes[2].ip, protocol=Protocol.ICMP)
        result = net.route_packet(pkt)
        assert result["success"] is False
