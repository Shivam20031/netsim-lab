"""
topologies.py — Factory functions for common network topologies.
"""

from src.topology.network import Network
from src.topology.node import Node, NodeType
from src.topology.link import Link


def create_star_network(nodes: int = 5, hub_type: str = NodeType.SWITCH) -> Network:
    """Central hub/switch connected to N hosts."""
    net = Network("StarNet")
    hub = Node("Hub-0", node_type=hub_type)
    net.add_node(hub)
    for i in range(1, nodes + 1):
        host = Node(f"Host-{i}", node_type=NodeType.HOST)
        net.add_node(host)
        net.add_link(Link("Hub-0", f"Host-{i}", latency=1.0, bandwidth=100))
    return net


def create_ring_network(nodes: int = 6) -> Network:
    """Each node connected to its two neighbors in a ring."""
    net = Network("RingNet")
    ids = [f"Node-{i}" for i in range(nodes)]
    for nid in ids:
        net.add_node(Node(nid, node_type=NodeType.ROUTER))
    for i in range(nodes):
        net.add_link(Link(ids[i], ids[(i + 1) % nodes], latency=2.0, bandwidth=500))
    return net


def create_mesh_network(nodes: int = 4) -> Network:
    """Full mesh — every node connected to every other node."""
    net = Network("MeshNet")
    ids = [f"R{i}" for i in range(nodes)]
    for nid in ids:
        net.add_node(Node(nid, node_type=NodeType.ROUTER))
    for i in range(nodes):
        for j in range(i + 1, nodes):
            net.add_link(Link(ids[i], ids[j], latency=float(i + j), bandwidth=1000))
    return net


def create_bus_network(nodes: int = 5) -> Network:
    """Linear bus — each node connected only to adjacent nodes."""
    net = Network("BusNet")
    ids = [f"Node-{i}" for i in range(nodes)]
    for nid in ids:
        net.add_node(Node(nid, node_type=NodeType.HOST))
    for i in range(nodes - 1):
        net.add_link(Link(ids[i], ids[i + 1], latency=0.5, bandwidth=100))
    return net


def create_internet_like(num_backbone: int = 3, hosts_per_router: int = 3) -> Network:
    """Backbone routers in a mesh, with hosts hanging off each."""
    net = Network("InternetLike")
    router_ids = [f"R{i}" for i in range(num_backbone)]
    for rid in router_ids:
        net.add_node(Node(rid, node_type=NodeType.ROUTER))
    # Full mesh backbone
    for i in range(num_backbone):
        for j in range(i + 1, num_backbone):
            net.add_link(Link(router_ids[i], router_ids[j], latency=10.0, bandwidth=10000))
    # Hosts per router
    for i, rid in enumerate(router_ids):
        for h in range(hosts_per_router):
            hid = f"H{i}_{h}"
            net.add_node(Node(hid, node_type=NodeType.HOST))
            net.add_link(Link(rid, hid, latency=1.0, bandwidth=100))
    return net
