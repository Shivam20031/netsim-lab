"""
link.py — Network Link with latency, bandwidth, and packet loss modeling.
"""

import random
from dataclasses import dataclass, field


@dataclass
class Link:
    src:         str
    dst:         str
    latency:     float = 1.0     # ms
    bandwidth:   float = 1000.0  # Mbps
    loss_rate:   float = 0.0     # 0.0–1.0
    is_up:       bool  = True
    metadata:    dict  = field(default_factory=dict)

    def simulate_transmission(self, packet_size_bytes: int = 64) -> dict:
        """
        Simulate sending a packet across this link.
        Returns a dict with delay (ms), dropped (bool), and throughput.
        """
        if not self.is_up:
            return {"delay": 0, "dropped": True, "reason": "link_down"}

        dropped = random.random() < self.loss_rate
        if dropped:
            return {"delay": 0, "dropped": True, "reason": "packet_loss"}

        # Transmission delay = size / bandwidth
        transmission_delay = (packet_size_bytes * 8) / (self.bandwidth * 1e6) * 1000  # ms
        jitter = random.uniform(0, self.latency * 0.1)
        total_delay = self.latency + transmission_delay + jitter

        return {
            "delay":    round(total_delay, 3),
            "dropped":  False,
            "reason":   None,
        }

    def cost(self) -> float:
        """Link cost for routing (inverse bandwidth + latency)."""
        if not self.is_up:
            return float("inf")
        return self.latency + (1000 / self.bandwidth)

    def bring_down(self):
        self.is_up = False

    def bring_up(self):
        self.is_up = True

    def __repr__(self):
        status = "UP" if self.is_up else "DOWN"
        return f"Link({self.src}<->{self.dst} | {self.latency}ms | {self.bandwidth}Mbps | loss={self.loss_rate*100:.1f}% | {status})"
