"""
network.py — Network graph manager with Dijkstra shortest-path routing.
"""

import heapq
from typing import Optional
from src.topology.node import Node
from src.topology.link import Link


class Network:
    def __init__(self, name: str = "SimNet"):
        self.name   = name
        self.nodes: dict[str, Node] = {}
        self.links: dict[tuple, Link] = {}   # (src, dst) → Link
        self._adj:  dict[str, list]   = {}   # adjacency list

    # ── Mutators ────────────────────────────────────────────────────────────

    def add_node(self, node: Node):
        self.nodes[node.node_id] = node
        self._adj.setdefault(node.node_id, [])

    def add_link(self, link: Link, bidirectional: bool = True):
        self.links[(link.src, link.dst)] = link
        self._adj.setdefault(link.src, []).append(link.dst)
        if bidirectional:
            reverse = Link(link.dst, link.src, link.latency, link.bandwidth, link.loss_rate)
            self.links[(link.dst, link.src)] = reverse
            self._adj.setdefault(link.dst, []).append(link.src)

    def remove_node(self, node_id: str):
        if node_id in self.nodes:
            del self.nodes[node_id]
            self._adj.pop(node_id, None)
            self.links = {k: v for k, v in self.links.items() if node_id not in k}
            for neighbors in self._adj.values():
                if node_id in neighbors:
                    neighbors.remove(node_id)

    # ── Routing ─────────────────────────────────────────────────────────────

    def shortest_path(self, src: str, dst: str) -> Optional[list[str]]:
        """Dijkstra's shortest path (by link cost). Returns node list or None."""
        if src not in self.nodes or dst not in self.nodes:
            return None

        dist    = {n: float("inf") for n in self.nodes}
        prev    = {}
        dist[src] = 0
        heap    = [(0, src)]

        while heap:
            cost, u = heapq.heappop(heap)
            if cost > dist[u]:
                continue
            if u == dst:
                break
            node = self.nodes.get(u)
            if node and not node.is_alive:
                continue
            for v in self._adj.get(u, []):
                link = self.links.get((u, v))
                if link:
                    new_cost = dist[u] + link.cost()
                    if new_cost < dist[v]:
                        dist[v] = new_cost
                        prev[v] = u
                        heapq.heappush(heap, (new_cost, v))

        if dist[dst] == float("inf"):
            return None

        path, cur = [], dst
        while cur in prev:
            path.append(cur)
            cur = prev[cur]
        path.append(src)
        return list(reversed(path))

    def route_packet(self, packet) -> dict:
        """Route a packet through the network, recording hops and delays."""
        src_node = next((n for n in self.nodes.values() if n.ip == packet.src_ip), None)
        dst_node = next((n for n in self.nodes.values() if n.ip == packet.dst_ip), None)

        if not src_node or not dst_node:
            packet.drop()
            return {"success": False, "reason": "host_not_found"}

        path = self.shortest_path(src_node.node_id, dst_node.node_id)
        if not path:
            packet.drop()
            return {"success": False, "reason": "no_route"}

        total_delay = 0.0
        for i in range(len(path) - 1):
            link = self.links.get((path[i], path[i+1]))
            if link:
                result = link.simulate_transmission(packet.size)
                if result["dropped"]:
                    packet.drop()
                    return {"success": False, "reason": result["reason"], "path": path[:i+1]}
                total_delay += result["delay"]
            packet.record_hop(path[i])
            if packet.ttl <= 0:
                packet.drop()
                return {"success": False, "reason": "ttl_exceeded", "path": path}

        packet.record_hop(path[-1])
        packet.deliver()
        return {"success": True, "path": path, "total_delay_ms": round(total_delay, 3)}

    # ── Introspection ────────────────────────────────────────────────────────

    def topology_summary(self) -> str:
        lines = [f"Network: {self.name}", f"  Nodes : {len(self.nodes)}", f"  Links : {len(self.links) // 2}"]
        for nid, node in self.nodes.items():
            lines.append(f"    {node}")
        return "\n".join(lines)
