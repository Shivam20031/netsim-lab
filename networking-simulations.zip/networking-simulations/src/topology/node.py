"""
node.py — Network Node (Router / Switch / Host) for topology simulation.
"""

from dataclasses import dataclass, field
from typing import Optional


class NodeType:
    HOST    = "host"
    ROUTER  = "router"
    SWITCH  = "switch"
    GATEWAY = "gateway"


@dataclass
class Node:
    node_id:   str
    node_type: str               = NodeType.HOST
    ip:        Optional[str]     = None
    mac:       Optional[str]     = None
    is_alive:  bool              = True
    metadata:  dict              = field(default_factory=dict)

    def __post_init__(self):
        # Auto-assign placeholder IPs/MACs for simulation
        if not self.ip:
            octets = abs(hash(self.node_id)) % (256**3)
            a = (octets >> 16) & 0xFF
            b = (octets >> 8)  & 0xFF
            c = octets         & 0xFF
            self.ip = f"10.{a % 10}.{b % 256}.{c % 256}"
        if not self.mac:
            h = abs(hash(self.node_id))
            self.mac = ":".join(f"{(h >> (i * 8)) & 0xFF:02x}" for i in range(6))

    def fail(self):
        self.is_alive = False

    def recover(self):
        self.is_alive = True

    def __repr__(self):
        status = "UP" if self.is_alive else "DOWN"
        return f"Node({self.node_id} | {self.node_type} | {self.ip} | {status})"
