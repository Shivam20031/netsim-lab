"""
packet.py — Core Packet data model for networking simulations.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Any
import time
import uuid


class Protocol(Enum):
    TCP  = "TCP"
    UDP  = "UDP"
    ICMP = "ICMP"
    ARP  = "ARP"
    OSPF = "OSPF"
    BGP  = "BGP"


class PacketStatus(Enum):
    CREATED    = "CREATED"
    IN_TRANSIT = "IN_TRANSIT"
    DELIVERED  = "DELIVERED"
    DROPPED    = "DROPPED"
    DELAYED    = "DELAYED"


@dataclass
class Packet:
    src_ip:    str
    dst_ip:    str
    protocol:  Protocol
    payload:   Any               = None
    src_port:  Optional[int]     = None
    dst_port:  Optional[int]     = None
    ttl:       int               = 64
    size:      int               = 64          # bytes
    seq:       int               = 0
    ack:       int               = 0
    flags:     dict              = field(default_factory=dict)
    packet_id: str               = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: float             = field(default_factory=time.time)
    status:    PacketStatus      = PacketStatus.CREATED
    hops:      list              = field(default_factory=list)

    def record_hop(self, node_id: str):
        self.hops.append((node_id, time.time()))
        self.ttl -= 1

    def drop(self):
        self.status = PacketStatus.DROPPED

    def deliver(self):
        self.status = PacketStatus.DELIVERED

    def rtt(self) -> Optional[float]:
        """Return round-trip time in ms if at least 2 hops recorded."""
        if len(self.hops) >= 2:
            return (self.hops[-1][1] - self.hops[0][1]) * 1000
        return None

    def __repr__(self):
        return (
            f"Packet(id={self.packet_id}, "
            f"{self.src_ip}->{self.dst_ip}, "
            f"proto={self.protocol.value}, "
            f"ttl={self.ttl}, "
            f"status={self.status.value})"
        )
