"""
icmp.py — ICMP Ping simulation.
"""

import time
from src.topology.network import Network
from src.utils.packet import Packet, Protocol, PacketStatus


class ICMPSimulator:
    def __init__(self, network: Network):
        self.network = network

    def ping(self, src_id: str, dst_id: str, count: int = 4, size: int = 64) -> dict:
        """
        Simulate ICMP echo request/reply between two nodes.
        Returns ping statistics.
        """
        src_node = self.network.nodes.get(src_id)
        dst_node = self.network.nodes.get(dst_id)

        if not src_node:
            return {"error": f"Source node '{src_id}' not found."}
        if not dst_node:
            return {"error": f"Destination node '{dst_id}' not found."}

        results = []
        for seq in range(count):
            pkt = Packet(
                src_ip   = src_node.ip,
                dst_ip   = dst_node.ip,
                protocol = Protocol.ICMP,
                size     = size,
                seq      = seq,
                flags    = {"type": "echo_request"},
            )
            result = self.network.route_packet(pkt)

            # Simulate echo reply (reverse path)
            rtt = None
            if result["success"]:
                reply = Packet(
                    src_ip   = dst_node.ip,
                    dst_ip   = src_node.ip,
                    protocol = Protocol.ICMP,
                    size     = size,
                    seq      = seq,
                    flags    = {"type": "echo_reply"},
                )
                reply_result = self.network.route_packet(reply)
                if reply_result["success"]:
                    rtt = result["total_delay_ms"] + reply_result["total_delay_ms"]

            results.append({
                "seq":       seq,
                "success":   result["success"],
                "rtt_ms":    round(rtt, 3) if rtt else None,
                "hops":      len(result.get("path", [])) - 1,
                "reason":    result.get("reason"),
            })

        sent      = count
        received  = sum(1 for r in results if r["success"])
        rtts      = [r["rtt_ms"] for r in results if r["rtt_ms"] is not None]
        loss_pct  = round((sent - received) / sent * 100, 1)

        summary = {
            "target":       dst_id,
            "packets_sent": sent,
            "received":     received,
            "loss_pct":     loss_pct,
            "rtt_min_ms":   round(min(rtts), 3) if rtts else None,
            "rtt_max_ms":   round(max(rtts), 3) if rtts else None,
            "rtt_avg_ms":   round(sum(rtts) / len(rtts), 3) if rtts else None,
            "results":      results,
        }

        # Pretty print
        print(f"\nPING {src_id} → {dst_id} ({dst_node.ip}): {size} bytes of data")
        for r in results:
            if r["success"]:
                print(f"  [{r['seq']}] {size} bytes: rtt={r['rtt_ms']}ms  hops={r['hops']}")
            else:
                print(f"  [{r['seq']}] Request timeout ({r['reason']})")
        print(f"\n--- {dst_id} ping statistics ---")
        print(f"  {sent} packets transmitted, {received} received, {loss_pct}% packet loss")
        if rtts:
            print(f"  rtt min/avg/max = {summary['rtt_min_ms']}/{summary['rtt_avg_ms']}/{summary['rtt_max_ms']} ms\n")

        return summary
