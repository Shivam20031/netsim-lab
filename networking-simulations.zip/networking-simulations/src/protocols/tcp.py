"""
tcp.py — TCP connection simulation (3-way handshake, data transfer, teardown).
"""

import random
import time
from enum import Enum
from src.utils.packet import Packet, Protocol


class TCPState(Enum):
    CLOSED      = "CLOSED"
    SYN_SENT    = "SYN_SENT"
    SYN_RECEIVED= "SYN_RECEIVED"
    ESTABLISHED = "ESTABLISHED"
    FIN_WAIT_1  = "FIN_WAIT_1"
    CLOSE_WAIT  = "CLOSE_WAIT"
    CLOSED_DONE = "CLOSED_DONE"


class TCPConnection:
    def __init__(self, src_ip, dst_ip, src_port, dst_port, network=None):
        self.src_ip   = src_ip
        self.dst_ip   = dst_ip
        self.src_port = src_port
        self.dst_port = dst_port
        self.network  = network
        self.state    = TCPState.CLOSED
        self.seq      = random.randint(1000, 9999)
        self.ack      = 0
        self.rx_buf   = b""
        self.log      = []

    def _log(self, msg: str):
        entry = f"[{time.strftime('%H:%M:%S')}] {msg}"
        self.log.append(entry)
        print(f"  TCP  {entry}")

    def connect(self) -> bool:
        """Perform 3-way handshake."""
        # SYN
        self._log(f"SYN  → {self.dst_ip}:{self.dst_port}  seq={self.seq}")
        self.state = TCPState.SYN_SENT

        # SYN-ACK (simulated server response)
        server_seq = random.randint(1000, 9999)
        self.ack = self.seq + 1
        self._log(f"← SYN-ACK  seq={server_seq}  ack={self.ack}")
        self.state = TCPState.SYN_RECEIVED

        # ACK
        self.seq += 1
        self._log(f"ACK  → {self.dst_ip}:{self.dst_port}  ack={server_seq + 1}")
        self.state = TCPState.ESTABLISHED
        self._log("Connection ESTABLISHED")
        return True

    def send(self, data: bytes) -> int:
        if self.state != TCPState.ESTABLISHED:
            raise RuntimeError(f"Cannot send in state {self.state}")
        self._log(f"DATA → {len(data)} bytes  seq={self.seq}")
        self.seq += len(data)
        return len(data)

    def receive(self, size: int = 4096) -> bytes:
        if self.state != TCPState.ESTABLISHED:
            raise RuntimeError(f"Cannot receive in state {self.state}")
        # Simulate server response
        response = b"HTTP/1.1 200 OK\r\nContent-Length: 13\r\n\r\nHello, World!"
        self._log(f"← DATA  {len(response)} bytes  ack={self.seq}")
        return response

    def close(self):
        """4-way FIN teardown."""
        self._log(f"FIN  → {self.dst_ip}:{self.dst_port}")
        self.state = TCPState.FIN_WAIT_1
        self._log(f"← FIN-ACK")
        self.state = TCPState.CLOSE_WAIT
        self._log(f"ACK  → sent")
        self.state = TCPState.CLOSED_DONE
        self._log("Connection CLOSED")


class TCPSimulator:
    def __init__(self, network=None):
        self.network     = network
        self.connections = {}

    def connect(self, src: str, dst: str, src_port: int, dst_port: int) -> TCPConnection:
        print(f"\n{'='*50}")
        print(f"TCP Connect: {src}:{src_port} → {dst}:{dst_port}")
        print(f"{'='*50}")
        conn = TCPConnection(src, dst, src_port, dst_port, self.network)
        conn.connect()
        key = (src, src_port, dst, dst_port)
        self.connections[key] = conn
        return conn
