"""
mesh_routing.py — Demonstrate mesh routing with dynamic node failure and rerouting.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from src.topology.topologies import create_mesh_network
from src.protocols.icmp import ICMPSimulator
from src.utils.packet import Packet, Protocol


def main():
    print("=" * 60)
    print("  Mesh Network Routing Simulation")
    print("=" * 60)

    net = create_mesh_network(nodes=4)
    print("\n" + net.topology_summary())

    icmp = ICMPSimulator(net)

    # Initial ping
    print("\n[Step 1] Normal routing R0 → R3")
    icmp.ping("R0", "R3", count=3)

    # Show path
    path = net.shortest_path("R0", "R3")
    print(f"  Computed path: {' → '.join(path)}\n")

    # Simulate node failure
    print("[Step 2] Simulating R1 failure...")
    net.nodes["R1"].fail()
    print("  R1 is now DOWN\n")

    # Ping again — should reroute
    print("[Step 3] Routing R0 → R3 with R1 down (rerouting)")
    icmp.ping("R0", "R3", count=3)
    path2 = net.shortest_path("R0", "R3")
    print(f"  Rerouted path: {' → '.join(path2) if path2 else 'NO ROUTE'}\n")

    # Recovery
    print("[Step 4] R1 recovering...")
    net.nodes["R1"].recover()
    print("  R1 is back UP\n")

    print("[Step 5] Ping after recovery")
    icmp.ping("R0", "R3", count=2)


if __name__ == "__main__":
    main()
