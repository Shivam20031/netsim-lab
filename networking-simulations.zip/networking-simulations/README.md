# 🌐 Networking Simulations

A comprehensive Python-based networking simulation framework that models real-world protocols, topologies, and packet routing behaviors. Ideal for learning, testing, and visualizing how computer networks operate.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python)
![License](https://img.shields.io/badge/License-MIT-green)
![Status](https://img.shields.io/badge/Status-Active-brightgreen)

---

## 📚 Table of Contents

- [Features](#features)
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [Simulations](#simulations)
- [Usage Examples](#usage-examples)
- [Running Tests](#running-tests)
- [Contributing](#contributing)
- [License](#license)

---

## ✨ Features

- **Protocol Simulation**: TCP/IP, UDP, ARP, ICMP, OSPF, BGP
- **Topology Modeling**: Star, Ring, Mesh, Bus, Hybrid networks
- **Packet Routing**: Dijkstra, Bellman-Ford, Flooding algorithms
- **Network Events**: Packet loss, delay, congestion, node failure
- **Visual Output**: ASCII topology maps + JSON logs
- **Extensible**: Add custom protocols and topologies easily

---

## 🗂️ Project Structure

```
networking-simulations/
├── src/
│   ├── protocols/
│   │   ├── __init__.py
│   │   ├── tcp.py           # TCP connection simulation
│   │   ├── udp.py           # UDP datagram simulation
│   │   ├── arp.py           # ARP resolution simulation
│   │   ├── icmp.py          # Ping/ICMP simulation
│   │   └── ospf.py          # OSPF routing simulation
│   ├── topology/
│   │   ├── __init__.py
│   │   ├── node.py          # Network node (router/host/switch)
│   │   ├── link.py          # Network link with latency/bandwidth
│   │   ├── network.py       # Network graph manager
│   │   └── topologies.py    # Pre-built topology factories
│   └── utils/
│       ├── __init__.py
│       ├── logger.py        # Event logger
│       ├── visualizer.py    # ASCII topology renderer
│       └── packet.py        # Packet data model
├── tests/
│   ├── test_tcp.py
│   ├── test_routing.py
│   └── test_topology.py
├── examples/
│   ├── simple_ping.py
│   ├── mesh_routing.py
│   └── tcp_handshake.py
├── docs/
│   └── architecture.md
├── requirements.txt
├── setup.py
└── README.md
```

---

## 🚀 Getting Started

### Prerequisites

- Python 3.10+
- pip

### Installation

```bash
git clone https://github.com/yourusername/networking-simulations.git
cd networking-simulations
pip install -r requirements.txt
```

### Quick Start

```bash
python examples/simple_ping.py
```

---

## 🔬 Simulations

| Simulation | Description | File |
|-----------|-------------|------|
| TCP 3-Way Handshake | Full SYN/SYN-ACK/ACK simulation | `protocols/tcp.py` |
| UDP Broadcast | Datagram delivery with loss modeling | `protocols/udp.py` |
| ARP Resolution | MAC address discovery | `protocols/arp.py` |
| ICMP Ping | Round-trip time calculation | `protocols/icmp.py` |
| OSPF Routing | Link-state routing convergence | `protocols/ospf.py` |
| Shortest Path | Dijkstra on weighted graph | `topology/network.py` |
| Node Failure | Dynamic rerouting on failure | `examples/mesh_routing.py` |

---

## 💡 Usage Examples

### Simulate a Ping

```python
from src.topology.topologies import create_star_network
from src.protocols.icmp import ICMPSimulator

net = create_star_network(nodes=5)
icmp = ICMPSimulator(net)
result = icmp.ping("Host-1", "Host-4")
print(result)
# RTT: 12ms | Hops: 2 | Status: SUCCESS
```

### Build a Custom Topology

```python
from src.topology.network import Network
from src.topology.node import Node
from src.topology.link import Link

net = Network()
net.add_node(Node("Router-A", node_type="router"))
net.add_node(Node("Router-B", node_type="router"))
net.add_node(Node("Host-1", node_type="host"))
net.add_link(Link("Router-A", "Router-B", latency=5, bandwidth=1000))
net.add_link(Link("Router-B", "Host-1", latency=2, bandwidth=100))

path = net.shortest_path("Router-A", "Host-1")
print(path)  # ['Router-A', 'Router-B', 'Host-1']
```

### TCP Handshake

```python
from src.protocols.tcp import TCPSimulator

tcp = TCPSimulator()
conn = tcp.connect(src="192.168.1.1", dst="10.0.0.5", src_port=5000, dst_port=80)
conn.send(b"GET / HTTP/1.1\r\nHost: 10.0.0.5\r\n\r\n")
response = conn.receive()
conn.close()
```

---

## 🧪 Running Tests

```bash
# All tests
python -m pytest tests/ -v

# Specific module
python -m pytest tests/test_tcp.py -v

# With coverage
pip install pytest-cov
python -m pytest tests/ --cov=src --cov-report=html
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/ospf-simulation`
3. Commit your changes: `git commit -m "Add OSPF convergence simulation"`
4. Push and open a Pull Request

Please follow the [contribution guidelines](docs/architecture.md).

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.
